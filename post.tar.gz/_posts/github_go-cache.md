title: 每周一个Github项目【第八期】go-cache
categories: 个人随笔
date: 2017-10-08 18:00:00
tags: [Github Every Week]
---
用Go实现的驻留内存的键值对存储/高速缓存（类似Memcached），适合单机应用 // An in-memory key:value store/cache (similar to Memcached) library for Go, suitable for single-machine applications.
<!--more-->

| 名称| go-cache|
|------|-----|
|地址|[Github](https://github.com/patrickmn/go-cache)|
|作者|[patrickmn](https://github.com/patrickmn)等|
|Brief Intro| An in-memory key:value store/cache (similar to Memcached) library for Go, suitable for single-machine applications.|
|LICENSE|MIT|
|starts|1,119|

go-cache是一个驻留内存的键值对存储/高速缓存（类似Memcached），适合单机应用。
它大致上可以认为是一个线程安全的`map[string]interface{}`，同时支持时间过期。

任何对象都可以被存储，可以指定过期时间，也可以指定为永久存在。go-cache是线程安全的。

虽然go-cache并非作为持久存储而设计的，但是整个高速缓存的内容可以通过`c.Items()`序列化以后存储，然后使用`NewFrom()`重新加载。

安装
----

```bash
go get github.com/patrickmn/go-cache
```

用法

```go
import (
	"fmt"
	"github.com/patrickmn/go-cache"
	"time"
)

func main() {
	// 创建一个默认过期时间为5分钟，清理间隔时间为10分钟的高速缓存
	c := cache.New(5*time.Minute, 10*time.Minute)

	// 设置“foo”键的值为“bar”，默认过期时间
	c.Set("foo", "bar", cache.DefaultExpiration)

	// 设置“baz”为42，不过期
	// 如果没有重置或者删除的话，它不会被删除
	c.Set("baz", 42, cache.NoExpiration)

	// 获取"foo"对应的字符串
	foo, found := c.Get("foo")
	if found {
		fmt.Println(foo)
	}

	// 因为Go是一种静态类型语言，而cache可以存储任何类型，因此可以使用断言来判断任意类型
	foo, found := c.Get("foo")
	if found {
		MyFunction(foo.(string))
	}

	// 需要高性能？那就存指针吧
	c.Set("foo", &MyStruct, cache.DefaultExpiration)
	if x, found := c.Get("foo"); found {
		foo := x.(*MyStruct)
			// ...
	}
}
```

用法相对很简单，实现也不难，具体文档参考[文档](https://godoc.org/github.com/patrickmn/go-cache)