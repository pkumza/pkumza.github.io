title: 每周一个Github项目【第一期】onionscan
categories: 个人随笔
date: 2017-08-04 20:30:00
tags: [Github Every Week]
---

一个用于探查深网的免费开源工具 // A free and open source tool for investigating the Dark Web
<!--more-->

| 名称| OnionScan|
|------|-----|
|地址|[Github](https://github.com/s-rah/onionscan)|
|作者|s-rah等|
|Brief Intro|OnionScan is a free and open source tool for investigating the Dark Web.|
|LICENSE|MIT|
|starts|912|

所以这个东西叫做扫描洋葱呗。

>OnionScan是一个用于探查深网（Dark Web）的免费开源工具。对于匿名和隐私空间的所有惊人的技术创新，总是有一个不断的威胁，没有有效的技术补丁，那就是人为错误。

>无论是操作安全漏洞还是软件配置错误 - 最常见的是匿名攻击不是来自于破坏底层系统，而是来自于我们自己。

>OnionScan有两个主要目标：

>希望帮助隐藏服务的运营者找到并修复其服务的操作安全问题。希望帮助他们检测配置错误，希望启发新一代匿名工程项目，保护人们的隐私。

>其次，OnionScan希望帮助研究人员和调查人员监控和跟踪黑网站。当然OnionScan并不一定同意调查者的动机，但通过使调查变得容易，希望为新的匿名技术创造一个强大的激励（见目标1）

OnionScan这个工具的探测能力很强，但是作为一个爬虫类的应用，首先需要一个proxy。该工程使用的是tor proxy，这个我在测试的时候还没有搞定，所以具体实际测试也就没进行。具体作用、效果待研究。
