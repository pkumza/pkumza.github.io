title: 每周一个Github项目【第五期】免费编程书
categories: 个人随笔
date: 2017-09-01 18:00:00
tags: [Github Every Week]
---

📚 免费的编程书 // 📚 Freely available programming books
<!--more-->

| 名称| Freely available programming books|
|------|-----|
|地址|[Github](https://github.com/EbookFoundation/free-programming-books)|
|组织|EbookFoundation|
|Brief Intro| 📚 Freely available programming books|
|LICENSE|Creative Commons Attribution 4.0 International License|
|starts|92,214|

# 介绍

这周比较忙，所以就不介绍一些需要深入了解的Repo了，写一个比较水的，但是点赞数特别多的。

这一个Repo在Github上的Star数目为92.2k，为世界第三，但是对应的编程语言却是空。如果非要说一种语言的话，那么这个repo是用markdown来组成的。

里面免费的书籍实在是太多了，汇集各种语言、各类领域的计算机类免费书籍，支持的语言也有26种之多，大家可以重点关注一下[中文书籍](https://github.com/EbookFoundation/free-programming-books/blob/master/free-programming-books-zh.md)和[英文书籍](https://github.com/EbookFoundation/free-programming-books/blob/master/free-programming-books.md)

顺便一提下，想搜搜看Github上最最最最最火的Repo，点[这个链接](https://github.com/search?o=desc&q=stars%3A%3E1000&s=stars&type=Repositories&utf8=%E2%9C%93)就可以了。越火的repo，相关介绍也就越多，中文版的也有，所以接下来一般不会选择太火的介绍。如果又介绍了个，只能说明近期较忙啦。
