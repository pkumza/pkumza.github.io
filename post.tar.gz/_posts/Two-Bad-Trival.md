title: '两次尝试'
categories: 个人随笔
date: 2014-06-06 14:31:18
tags: [Commerce, Drupal]
---
# Commerce Kickstart

首先，想学习电子商务模块，而Commerce Kickstart是一套完整的Drupal模块，觉得可以尝试一下。
结果，第一轮尝试以失败告终。
首先是下载了整个Commerce Kickstart，没有问题，然后按照装Drupal的方法进行配置，完成，一切ok。但是当进入网页的时候，就会发现，每次都需要一分半的时间来加载。开发模式中找出原因，是css下载的问题，每次都到googleapi去下载css，而校园网最近对于Google的支持很有问题，Google的网页都打不开，自然也无法下载css，于是卡在那里，直到确实打不开，才把网页显示出来。这个暂时还没有想到别的好方法，暂时的方法就是把网断了。
把网断了之后，尝试修改一个Theme，修改为了系统的普通Theme，然后退出了。后来想重新登陆，发现悲剧了，因为普通Theme连主页都没有，连登录框都没有，所以便没有办法改回主题，因此必须要重新安装了。主要原因是没有指导书或者教程，自己尝试，还是英文的，到处碰壁，最终导致第一轮尝试彻底失败。

# Acquia

尝试acquia dev同样是碰壁。打开Acquia，然后想要登陆一下PHPMyAdmin，浏览器说不支持utf-8，到网上到处搜解决方法，据说把config.inc.php文件给删了就行了，试了一下确实可以，然后可以登陆了，被登陆界面卡在那里。明明没设置用户名密码，这里死活需要输入。于是，华丽丽地放弃了Acquia。后来知道用户是drupaluser密码是空，但是这又只能在那个config.inc.php存在的情况下才能使用，存在就意味着又会有utf-8错误。因此，对于Acquia DEV的尝试也失败了。

> Acquia is a software-as-a-service company co-founded by Dries Buytaert and Jay Batson to provide enterprise products, services, and technical support for open-source web content management platform Drupal. It is financed by venture capital, receiving $118.5 million in six rounds.
>  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; -- From Wiki.
<!--more-->

# Commerce

还有对Commerce模块的尝试。下载了Commerce模块，以及依赖模块，ok可以用，心里觉得好方便，这么就安装好了。不过，安装好了然后呢？其实Views模块，也就是试图模块还是半生不熟的，Libraries就更不知道是干什么的了。Rules模块，给Drupal的行为指定规则的，没学过，而Commerce模块需要指定很多的规则。有些是系统自带的，有些是自定义添加的，对Rules模块不懂，那么怎么才能对Commerce增加方便的规则呢？
在这些都不懂的情况下，还是开始尝试Commerce模块了。
首先，尝试一个一个启用子模块，最大的特点是启用后发现没什么区别，就是上面控制栏目多了Store。Store下面有小的选项。根据这些选项能够做什么呢？添加了Product模块后，可以添加商品了oh yes，然后又勾选了Product UI模块，仍然不知道商品在那里现实哇。链接是什么，基础内容和视图模块有区别吗？还是不懂额。
后来，把Commerce除了Tax，其他模块全部勾选了，仍然找不到商品页在哪。
更头疼的问题出现了，好不容易勾选了Cart，购物车，但是怎么看购物车呢？使用一个普通账号登陆，该是博客还是博客，该是主页还是主页，怎么和Store有任何关联？普通账号和Store的账号有什么对应关系？尝试在Store里面增加匿名用户也好，增加非匿名用户也好，完全不懂作为用户怎么观察商品，更不知道自己的购物车在哪，就不要说怎么把商品加入购物车了。
总之一切都是乱乱的，没有良好的教程指导，所有的努力都是泥牛入海，太难了。

# My Plan

前面是有很多失败，不过也找到了一些有用的资料，准备按照资料来进行学习。
* [Drupal7 字段 视图 关系](http://www.56.com/w12/play_album-aid-12312528_vid-MTEwNDIwMzA5.html) 上下两套视频。赶紧在这个时候把字段和视图再学一学，把握内容关系。
* [Entity](http://drupalchina.cn/node/1828)把新的概念Entity了解了。
* 有一本书《[Drupal7基础]（Beginning.Drupal.7）.Todd.Tomlinson.》，值得去读。虽然是英文版的，读起来会有困难，但是全面是肯定的。读不读得懂，适合不适合，看造诣了。
* [Drupal常用模块简介](http://www.365joomla.com/Drupal/Drupal常用模块简述.html)对常用模块分别是干啥的做一个分析，值得看一看了解一下。
* 最后就是等待看一看有什么收费的质量高的教程了。