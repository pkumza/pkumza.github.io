title: HTTP 简史复习
categories: 个人随笔
date: 2018-10-04 21:00:00
tags: [技术随笔]
---

简要复习一下HTTP的发展历史。

<!--more-->

## HTTP/0.9

初代不成熟协议，只支持`GET`命令，仅接受HTML格式的子串，一次请求结束之后TCP连接随即关闭。

## HTTP/1.0

不仅支持HTML，还支持图片、视频、二进制文件等。
增加了 POST HEAD，
每次Req和Resp都必须含有头部。整个头部只能使用ASCII编码
新增了状态码、权限、缓存、内容编码(content encoding)等功能。
新增Content-Type字段。

缺点：
但是每次只能发送一个请求，三次握手比较慢，另外需要慢启动。

连接复用采用 `Connection: keep-alive` 字段，该字段非标准。

## HTTP/1.1

RFC 2616
第一个有正式标准的版本。

举个 🌰

```
$> telnet website.org 80
Connected to xxx.xxx.xxx.xxx

GET /index.html HTTP/1.1 ①
Host: website.org
User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_4)... (snip)
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
Accept-Encoding: gzip,deflate,sdch
Accept-Language: en-US,en;q=0.8
Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.3
Cookie: __qca=P0-800083390... (snip)

HTTP/1.1 200 OK ②
Server: nginx/1.0.11
Connection: keep-alive
Content-Type: text/html; charset=utf-8
Via: HTTP/1.1 GWA
Date: Wed, 25 Jul 2012 20:23:35 GMT
Expires: Wed, 25 Jul 2012 20:23:35 GMT
Cache-Control: max-age=0, no-cache
Transfer-Encoding: chunked

100  ③
<!doctype html>
(snip)

100
(snip)

0 ④

GET /favicon.ico HTTP/1.1 ⑤
Host: www.website.org
User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_7_4)... (snip)
Accept: */*
Referer: http://website.org/
Connection: close ⑥
Accept-Encoding: gzip,deflate,sdch
Accept-Language: en-US,en;q=0.8
Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.3
Cookie: __qca=P0-800083390... (snip)

HTTP/1.1 200 OK ⑦
Server: nginx/1.0.11
Content-Type: image/x-icon
Content-Length: 3638
Connection: close
Last-Modified: Thu, 19 Jul 2012 17:51:44 GMT
Cache-Control: max-age=315360000
Accept-Ranges: bytes
Via: HTTP/1.1 GWA
Date: Sat, 21 Jul 2012 21:35:22 GMT
Expires: Thu, 31 Dec 2037 23:55:55 GMT
Etag: W/PSA-GAu26oXbDi

(icon data)
(connection closed)
```

①：附带了encoding，charset和cookie元信息请求HTML文件
②：分块传输结果
③：分块的大小，以ASCII 十六进制表示。 100代表256字节。
④：用0，代表整个Response分块结束。
⑤：使用同一条TCP连接请求图标文件
⑥：提醒服务器，这个连接将不再被复用，可以关闭连接。
⑦：返回图标文件的信息，并在结尾处关闭连接。

以上样例重点贯彻了`HTTP/1.1`的连接复用、分块以及显式关闭等特征。

特征：

1. 默认TCP连接不关闭，可以被多个请求复用。不像HTTP/1.0还必须明确指明 Connection: Keep-Alive。
2. 管道机制：同一个TCP连接，客户端可以发送多个请求。为了切分每个请求，必须在头部注明Content-Length
3. 分块传输 chunk。

其他功能

增加了 content, encoding, character set 等字段。
Host 字段
PUT PATCH HEAD OPTIONS DELETE

缺点

队头堵塞 Head-of-line blocking

## SPDY

谷歌自研 2009年 ，HTTP/2的基础

## HTTP/2

注意，不叫`HTTP/2.0`，下一个版本将是`HTTP/3`。

二进制协议

HTTP/1.1 的header肯定是ASCII，数据体可以是文本或二进制。
HTTP/2 是一个彻底的二进制协议，header和body都是二进制，并且统称为`帧`：头信息帧和数据帧。

多工 Multiplexing

HTTP/2 复用了TCP连接，在一个连接里，客户端和浏览器都可以同时发送多个请求或回应，而不是按照顺序。这避免了`队头堵塞`。

数据流

因为HTTP/2的数据包不按顺序发送，所以要指出每个数据包属于哪个回应。

每个请求或回应的所有数据包，称为一个数据流。每个数据流有个独一无二的ID。
客户端来的数据包的ID是奇数，服务端发送的数据包ID是偶数。

头信息压缩

一方面头可以压缩；另一方面，客户端和服务端维护了一张索引表，不用发送相同的字段。

服务器推送

未经过客户端的主动请求，服务器可以主动向客户端发送资源。

-----

参考：

http://www.ruanyifeng.com/blog/2016/08/http.html
https://github.com/abbshr/rfc7540-translation-zh_cn
https://tools.ietf.org/html/rfc7540 / https://httpwg.org/specs/rfc7540.html
https://developers.google.com/web/fundamentals/performance/http2/?hl=zh-cn
https://hpbn.co/brief-history-of-http/