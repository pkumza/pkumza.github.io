title: Mediakit报告设备商的空间不足以执行此操作的纯MAC解法
date: 2018-03-09 19:06:39
categories: ['个人随笔']
toc: ture
tags: []
---

使用Mac对磁盘进行分区，显示“Mediakit报告设备商的空间不足以执行此操作”，该怎么办？

<!--more-->

# What

买了一个4TB的移动硬盘，准备进行分区给Time Machine用。
硬盘自带是HDFS的，所以连上Mac之后，准备使用自带的`磁盘工具.app`进行格式化。
无论是选择 `OS X 扩展（日志式）`还是选择`Apple文件系统`，都会报错

> Mediakit 报告设备上空间足以执行此操作

然而网上的所有中文解决办法，全部都是需要动用大名鼎鼎的`DiskGenius`磁盘工具。这个工具我以前使用过，确实做的很用心，在PC上使用非常方便。

但是，我临时手头没有任何Windows设备！怎么办？！

# How

开门见山，直接说说怎么解决。

首先打开命令行
如果你不知道什么是命令行，可以使用(访达/Finder)，在个人收藏里面打开`终端.app`。

键入如下内容

```bash
diskutil list
```

这个时候你会获得你的所有磁盘内容。

找到你刚连上的移动硬盘。如果你实在不知道哪个是你刚连上的，注意哪个地方有`external`或`physical` 

找到这个磁盘，譬如`disk2`，就运行下面的命令。如果不是`disk2`，那么用你的disk替换一下。

```bash
diskutil unmountDisk force disk2
```

然后写入一个纯0的200M启动扇区

```bash
sudo dd if=/dev/zero of=/dev/disk2 bs=1024 count=1024
```

最后，再次尝试使用命令行进行分区。

```bash
diskutil partitionDisk disk2 GPT JHFS+ "AWESOME DISK" 0g
```

至此，搞定。

# Why

产生错误的原因是对于超过4TB的磁盘来说，一定是使用GUID分区表。在这种情况下，必须需要一个200M的EFI分区，才能够进行分区。

APFS确实比HFS+有更高的优势，譬如COW等等，因此性能更高。
APFS甚至支持动态分区。
但是APFS不支持时间机器，所以我这个磁盘还是要用HFS+。
