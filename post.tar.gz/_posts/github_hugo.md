title: 每周一个Github项目【第四期】hugo
categories: 个人随笔
date: 2017-08-27 17:30:00
tags: [Github Every Week]
---

一个用Go实现的快速灵活的静态页面生成工具 // A Fast and Flexible Static Site Generator built with love in GoLang.
<!--more-->

| 名称| hugo|
|------|-----|
|地址|[Github](https://github.com/gohugoio/hugo)|
|作者|spf13等|
|Brief Intro|A Fast and Flexible Static Site Generator built with love in GoLang.|
|LICENSE|Apache 2.0|
|starts|19,204|

# 介绍

![HUGO](https://raw.githubusercontent.com/gohugoio/hugoDocs/master/static/img/hugo-logo.png)

Hugo 是一个快速灵活的静态页面生成工具。它在速度、易用性和可配置性上进行了优化。Hugo可以把一个包含内容、模板的文件夹渲染为一个完整的HTML网站。

Hugo基于Markdown文件。

Hugo可以在瞬间渲染出一个中等大小的网站。从经验来看，每一片内容的渲染只需要大概1微秒。

Hugo设计之初就是为了服务于博客、tumbles和文档。

[官网gohugo.io](http://gohugo.io/)

# 评价

hugo和hexo可以说是功能类似。

hexo是离线生成博客网页的工具，由js实现，基于node和npm这一套提醒。可以方便地生成整个博客，渲染markdown，使用theme。

然而，hexo也存在很多问题，第一是生成速度慢。生成速度和theme有很大关系，但是确实比较慢。最艰难的时候，我曾经每次写一篇新的博客，都需要大概10秒钟以上的时间来生成所有的静态页面。后来换了一个theme，更新了hexo，100个页面，加载时间长达1000ms，生成时间大概是231ms。

但是hugo在时间上有很大的优势，每次只需要90ms就解决所有的问题，快了十几倍。

另外，hexo的theme与主hexo的兼容性还有待商榷。有一些主题的兼容性很差，尤其是hexo更新以后，也许就不怎么支持了。

最后也是最重要的，npm的网络实在不敢恭维，很多时候爆出WARN、Error或者直接下载失败，也就真的卡在npm这里了。对于go来说，本身go的包管理，我认为会比npm好用。

当然，hexo我已经用了较长时间了，总体也比较熟练。如果没有使用过hexo，但是想要做一个静态博客的话，我建议使用hugo。
