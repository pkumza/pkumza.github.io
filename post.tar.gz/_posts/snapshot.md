title: Mac OS X屏幕快照完全指南
categories: 个人随笔
date: 2018-09-16 21:00:00
tags: [技术随笔, OS X]
---

Mac OS X提供了丰富的内嵌屏幕快照（截图）工具，但是默认的格式、截图位置等并不一定可以契合每一个用户的需求。好在我们使用命令行（Terminal.app 或者iTerm2等别的命令行工具）可以方便地定制屏幕快照。

<!--more-->

# 基础

在我们具体地讨论屏幕快照之前，我们先讲一下基本使用（经验丰富的用户可以跳过这个部分）

在Mac OS X中，有三种方式来截图：截取整个屏幕、截取选定的窗口、截取指定方形区域，以上每一个都可以用快捷键唤起。

Command + Shift + 3: 截取整个屏幕。如果你有多个屏幕，那么每个屏幕会分别被截在不同的图中。

Command + Shift + 4: 截取一个方形区域。接下来你可以用你的鼠标划取这个区域。

![](https://cdn1.tekrevue.com/wp-content/uploads/2013/05/20130530_screenshotcrosshairs-615x386.jpg)

Command + Shift + 4, 然后按下空格: 截取一个窗口区域。

使用上述快捷键，默认会把截图保存到桌面上。

如果你在按上述快捷键的时候，同时按住Control键，那么截到的图片会暂时存在剪贴板中。

除了上述三个功能之外，/应用程序/实用工具/抓图.app还提供定时截图的功能。它可以有一个10秒钟的等待时间，会在你点击`启动定时器`按钮之后的10秒钟完成截图。

# 使用终端命令行

后续每个效果，都得通过执行这句指令才能生效。

```bash
killall SystemUIServer
```

这句话起到了刷新作用。

# 改变格式

```
defaults write com.apple.screencapture type [format]
```

`[format]` 可以输入为

- bmp
- pdf
- jpg
- jp2
- tif
- pict
- tga
- png

譬如，你可以通过输入`defaults write com.apple.screencapture type jpg`把默认图片格式改为jpg

# 改变文件名

系统默认存储的文件名为`屏幕快照 [date] [time].[format]`，譬如`屏幕快照 2018-07-31 下午4.01.16.png`。
你无法把时间戳从文件名中移除，但是你可以改掉`屏幕快照`这个前缀。方法是输入：

```
defaults write com.apple.screencapture name [file name]
```

# 修改默认保存位置

默认是保存到桌面的。你可以手动改变保存位置。

命令是：
```bash
defaults write com.apple.screencapture location
```

首先，你必须要创建一个新的文件夹，当然你要了解你文件夹的位置。
譬如你创建了一个名字叫做`abc`的文件夹在桌面上，那么这个文件夹的位置就是~/Desktop/abc

例：

```bash
defaults write com.apple.screencapture location /Users/[username]/Desktop/abc/
```

# 窗口阴影

截图的时候默认是有窗口阴影的，你可以用命令改掉。

```
defaults write com.apple.screencapture disable-shadow -bool true
```

效果图：
![](https://cdn1.tekrevue.com/wp-content/uploads/2013/03/20130301_osxscreenshots_4.jpg)

----------

参考：
[The Complete Guide to Mac OS X Screenshots](https://www.tekrevue.com/tip/how-to-customize-screenshot-options-in-mac-os-x/)