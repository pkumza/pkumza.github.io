title: Emoji与Unicode
categories: 个人随笔
date: 2017-09-18 11:00:00
tags: [go]
---

Unicode的资源是非常宝贵的，而emoji的表情真的是越来越多，那么emoji是如何编码的呢？
<!--more-->
在普通的聊天软件中，譬如QQ，一些基本表情是采用普通字符的转义表示。譬如在字符串中检测到`[微笑]`，就自动替换为表情。
但是Emoji是一种特殊的字符，它是真正被编码入Unicode的字符。它在字符集里占据了U+1F300到U+1F9EF中的部分范围。

但是为了实现丰富的Emoji，这种表情不一定只占据一个字符，尤其是为了实现[emoji中立](https://emojipedia.org/neutral/)的时候，就需要1-2个字符来完成一个表情，最多需要7个字符。

现在用一段代码来举例 ：

```go
package main

import "fmt"
import "unicode/utf8"

func main() {
	strs := []string{`Golang够浪`, `a`, `©`, ``, `🐵`, `👲🏻`, `👲🏿`, `💇🏽‍♂️`, `👨‍👨‍👦‍👦`}
	for _, str := range strs {
		fmt.Printf("%s, rune count:%d, len:%d\n", str, utf8.RuneCountInString(str), len(str))
		for _, theRune := range str {
			fmt.Printf("%s : 0x%x | ", string(theRune), theRune)
		}
		fmt.Print("\n------\n")
	}
}
```

[*到 Playground中运行一下，查看结果*](https://play.golang.org/p/tnSsUw0nvf)

我们来逐段分析每一个内容。

字串`Golang够浪`一共有8个字符，其中`Golang`这六个字符，每个字符在utf8里占据1个字节的空间，而词语`够浪`中的每个汉字占据3个字节的空间。

`a`这种最基本的内容，在utf8里只占据1个字节，因为它们太常见了，依霍夫曼编码的思路，也必然应当使用短小的编码方式。

`©`是一个相对比较常见的符号，但是又不在0~127这128个最基本的字符中，在utf8中占据2个字节。

``这个字符是苹果公司的logo，别的操作系统不一定能够正确显示，相对来说非常不常见，在utf8中占据3个字节。在Mac系统中，只需要同时按下`⇧`（shift）+ `⌥`（option）+ `K` 即可。

`🐵`是一个猴子emoji表情，在utf8中占据4个字节。多数emoji表情都占据4个字节。

`👲🏻`是一个戴着中国帽的中国男人，它需要由`👲`戴着中国帽的男人，与`🏻`黄种肤色放在一起，两个字符拼凑而成，共需要8个字节。

同样地，`👲🏿`是一个戴着中国帽的黑人男人，它需要由`👲`戴着中国帽的男人，与`🏿`黑人肤色放在一起，两个字符拼凑而成，共需要8个字节。

`💇🏽‍♂️`剪头发的棕色人种男人由`💇‍`剪头发的普通女人加上`🏽‍`棕色肤色，加上200d连接符，再加上‍♂男性符号，最后加上U+fe0f符号构成，一共耗费17个字节。这一版本的Mac和iOS系统可能还显示不出来，新版本iOS推出以后估计就能显示出来了。

最长的，也是最能够体现中立性质的一个emoji表情是`👨‍👨‍👦‍👦`，它代表着`两个爸爸和两个儿子一家`。它由7个字符组成，分别是👨 : U+1f468 普通男人 | ‍ : U+200d 连接符 | 👨 : U+1f468 普通男人 | ‍ : U+200d 连接符 | 👦 : U+1f466  普通男孩 | ‍ : U+200d  连接符 | 👦 : U+1f466 普通男孩 | 组成。

相信这对你理解utf8和unicode概念上的区别也有帮助😆 ~ Enjoy the Emoji!🙂

## 附录

Emoji在不同的平台上的显示是不同的，参考[Emoji Unicode Tables](https://apps.timwhitlock.info/emoji/tables/unicode#block-1-emoticons)，总体来说Apple的Emoji实现最尊重原版。

Emoji随着时间的推移在不断地丰富，按照年份，版本也在不断整张，参考[emoji-versions](http://unicode.org/emoji/charts/emoji-versions.html)

Unicode 10.0在22个块中使用1,182个字符的表情符号标识，其中1,085个是单个表情符号，26个是区分指示符符号、成对组合形成标志表情符号，12个（＃，*和0-9）是键帽的基本字符emoji序列。

杂项符号和象形图块中768个代码点中的637个被认为是表情符号。补充符号和象形图块中148个代码点中的134个被认为是表情符号。表情符号块中的所有80个代码点都被认为是表情符号。运输和地图符号块中的107个代码点中的94个被认为是表情符号。杂项符号块中的256个代码点中的80个被认为是表情符号。Dingbats块中192个代码点中的33个被认为是表情符号。

所谓[emoji中立](https://emojipedia.org/neutral/)就是防止歧视。表情应该是无种族的，应该是无性别特异性的，同样一个表情应该拥有各种肤色，有男有女。

## 参考文献

1. [Emoji - Wikipedia](https://en.wikipedia.org/wiki/Emoji)
1. [Emoji表情传输和保存：对非BMP范围的Unicode字符的处理](https://gist.github.com/x7hub/ecacd20401042d61f68f)
1. [Emoji Unicode Tables](https://apps.timwhitlock.info/emoji/tables/unicode#block-1-emoticons)
1. [Emoji 5.0 data](http://www.unicode.org/Public/emoji/5.0/emoji-data.txt)
1. [Emoji中立](https://emojipedia.org/neutral/)
1. [Mac——如何输入⌘、⌥、⇧、⌃、⎋等特殊字符（链接1）](http://newping.cn/447)、 [（链接2）](http://blog.sina.com.cn/s/blog_5656bf3e0102w3ic.html)
