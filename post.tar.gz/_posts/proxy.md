title: 匿名代理、透传代理和精英代理之间的区别
categories: 个人随笔
date: 2017-12-04 21:00:00
tags: [技术随笔]
---
匿名代理、透传代理和精英代理之间的区别 / differences between transparent, anonymous and elite proxy
<!--more-->

作为一个代理的普通用户，你也许不知道你在用的代理到底是透明的，匿名的还是精英的。
你也许会倾向于使用精英代理，正如它名字指示的那样。那么这几种代理到底有什么区别呢？

首先，代理一般会在HTTP的Header中传输以下3个字段：

```
REMOTE_ADDR
HTTP_X_FORWARDED_FOR
HTTP_VIA
```

REMOTE_ADDR总是发送代理服务器的IP地址。

## 透传代理

对于透传代理（Transparent Proxy）来说，你真实IP地址会被放在HTTP_X_FORWARDED_FOR里面。这意味着网站可以知道代理的IP，还知道你真正的IP地址。
HTTP_VIA头也会发送，显示你正在使用代理服务器

## 匿名代理

匿名代理不会把你的真实IP写在`HTTP_X_FORWARDED_FOR`头里面。但是HTTP_VIA头还是透露了您正在使用一个代理服务器。

## 精英代理

精英代理只发送REMOTE_ADDR头,因此让你看起来像一个普通互联网用户不使用代理。

## 检测精英代理

精英代理并非不可以检测。
网站可以检查这个IP，是否使用了常用的代理接口（如8080、3128、8080、3128）。

可以使用以下网站来检测你是否匿名:[http://whoer.net/ext](http://whoer.net/ext) 或 [https://whoer.net/zh#extended](https://whoer.net/zh#extended)

