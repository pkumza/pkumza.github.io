title: 云原生的定义
categories: 个人随笔
date: 2018-12-23 21:00:00
tags: [技术随笔]
---

云原生是一个比较新的概念。
Pivotal 是相关领域的先行者。
[CNCF](https://www.cncf.io/)是一个2015年成立的基金会。
他们都对云原生有着自己的定义

<!--more-->

# Pivotal

Pivotal 最早给出了相关的定义。

> Cloud-native is an approach to building and running applications that exploits the advantages of the cloud computing delivery model. Cloud-native is about how applications are created and deployed, not where.
While today public cloud impacts the thinking about infrastructure investment for virtually every industry, a cloud-like delivery model isn’t exclusive to public environments. It's appropriate for both public and private clouds. Most important is the ability to offer nearly limitless computing power, on-demand, along with modern data and application services for developers. When companies build and operate applications in a cloud-native fashion, they bring new ideas to market faster and respond sooner to customer demands.

> Organizations require a platform for building and operating cloud-native applications and services that automates and integrates the concepts of DevOps, continuous delivery, microservices, and containers:

云原生是一种利用云计算交付模型的优势，来构建和运行应用程序的方法。 
云原生的关注点在于应用程序如何创建和部署，而不关注在哪里部署。
虽然今天的公共云影响了几乎每个行业的基础设施投资思想，但类似云的交付模式并不仅限于公共环境。
它适用于公共云和私有云。
云原生应当始终是架构团队的追求目标。
当我们能够为业务团队按需提供充沛的计算能力，现代化的数据库和应用程序服务，那么业务团队也就能够更快地把新想法推向市场，并更快地响应客户请求。

组织需要一个平台来构建和运行云原生应用程序和服务，以自动化和集成DevOps，持续交付，微服务和容器的概念：

# CNCF

云原生计算基金会（Cloud Native Computing Foundation）给出了另一个定义。

> Cloud native technologies empower organizations to build and run scalable applications in modern, dynamic environments such as public, private, and hybrid clouds. Containers, service meshes, microservices, immutable infrastructure, and declarative APIs exemplify this approach.

> These techniques enable loosely coupled systems that are resilient, manageable, and observable. Combined with robust automation, they allow engineers to make high-impact changes frequently and predictably with minimal toil.

> The Cloud Native Computing Foundation seeks to drive adoption of this paradigm by fostering and sustaining an ecosystem of open source, vendor-neutral projects. We democratize state-of-the-art patterns to make these innovations accessible for everyone.

> 云原生技术有利于各组织在公有云、私有云和混合云等新型动态环境中，构建和运行可弹性扩展的应用。

> 云原生的代表技术包括`容器`、`服务网格`、`微服务`、`不可变基础设施`和`声明式API`。

> 这些技术能够构建容错性好、易于管理和便于观察的松耦合系统。结合可靠的自动化手段，云原生技术使工程师能够轻松地对系统作出频繁和可预测的重大变更。

> 云原生计算基金会（CNCF）致力于培育和维护一个厂商中立的开源生态系统，来推广云原生技术。我们通过将最前沿的模式民主化，让这些创新为大众所用。
# 参考文献

- https://github.com/cncf/toc/blob/master/DEFINITION.md
- https://pivotal.io/cloud-native