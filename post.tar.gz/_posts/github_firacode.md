title: 每周一个Github项目【第七期】FiraCode
categories: 个人随笔
date: 2017-09-24 11:30:00
tags: [Github Every Week]
---

具备编程连字功能的等宽字体 // monospaced font with programming ligatures
<!--more-->

| 名称| FiraCode |
|------|-----|
|地址|[Github](https://github.com/gohugoio/hugo)|
|作者|tonsky等|
|Brief Intro|monospaced font with programming ligatures|
|LICENSE|SIL Open Font License 1.1|
|starts|17,400|

概述
-----

程序员在编程的时候会使用很多符号。在某些编程语言中，一个逻辑令牌可能由2至3个字符构成，譬如`->`，`<=`或`==`。
理想情况下，所有的编程语言都应该为操作员设计出完整的Unicode符号，但现在还没有。

Fira代码是Fira Mono字体的扩展，包含一组通用编程多字符组合的连字。这只是一个字体渲染功能：底层代码保持ASCII兼容，这有助于更快地阅读和理解代码。
另外，对于某些频繁的序列，如..或//，连字可以让我们纠正间距。

所有特殊字体：
![all_ligatures](https://github.com/tonsky/FiraCode/raw/master/showcases/all_ligatures.png)

编程样例
-----

Ruby：
![Ruby](https://github.com/tonsky/FiraCode/raw/master/showcases/ruby.png)

Elixir:
![elixir](https://github.com/tonsky/FiraCode/raw/master/showcases/elixir.png)

Go:
![Go](https://github.com/tonsky/FiraCode/raw/master/showcases/go.png)

安装
------

对于Mac系统来说，安装FiraCode还是比较容易的，只需要运行两条命令即可

```bash
brew tap caskroom/fonts
brew cask install font-fira-code
```

在系统中安装之后，还需要在对应的代码编辑器中进行适配，以VS Code为例，点击`⌘`+`,`，然后把以下代码粘贴进去即可：

```json
"editor.fontFamily": "Fira Code",
"editor.fontLigatures": true
```

届时安装完毕。这时`->`的显示就变成了`→`咯。当然作为等款字体，它和`→`还不太一样，还是会占据两个字符宽度的。