title: PyCharm EDU
date: 2016-09-07 21:38:16
categories: 学习笔记
tags: [Python]
description: "PyCharm 实在是Python程序员所赞叹的优秀IDE。这不重装了Windows之后，第一件事就是安装PyCharm。不过这次看官网，有一点儿区别，多了一个PyCharm EDU。本来呢，我以为EDU版本就是只需要上传学号或者是使用edu邮箱验证，就可以免费使用收费功能。不过现实却完全不是这样。囧oz"
---

# PyCharm

PyCharm 实在是Python程序员所赞叹的优秀IDE。这不重装了Windows之后，第一件事就是安装PyCharm。不过这次看官网，有一点儿区别，多了一个PyCharm EDU。

本来呢，我以为EDU版本就是只需要上传学号或者是使用edu邮箱验证，就可以免费使用收费功能。不过现实却完全不是这样。囧oz

# EDU

实际上呢，EDU版本只是为了方便老师教学，方便学生学习的一个PyCharm版本而已。自己学了Python很久了，正好看到有一个入门，想看看有什么知识可以巩固，不过看了一下发现这实在是太简单了。

不过不得不说，初学者的这些章节设计还是蛮好的，对于初学Python有很大帮助。以前别人问我怎么学Python，我会推荐liaoxuefeng.org去学，但是现在，我可以直接推荐PyCharm了。

从界面上看，和PyCharm略有区别，但是总体来说很相似。
安装文件呢要比CE还要略小一点。
功能当然看起来是不够全面的啦，不说了我去装PyCharm CE了。暂时没钱买Pro。

![](http://imglf.nosdn.127.net/img/MGpGUW9CdGlzcDZ3Q2F5L2N4alRKYXh4Znh2YkFrZWhXMW5GQUV1Mm56N1IrQ0hhQnBtby93PT0.png?imageView&thumbnail=1680x0&quality=96&stripmeta=0&type=jpg%7Cwatermark&type=2&text=wqkgWmFjaGFyeSAvIG1hcmNob24ubG9mdGVyLmNvbQ==&font=bXN5aA==&gravity=southwest&dissolve=30&fontsize=340&dx=16&dy=20&stripmeta=0)

![](http://imglf0.nosdn.127.net/img/MGpGUW9CdGlzcDZ3Q2F5L2N4alRKZjUvOWRpczlEU2drUG1vV1NxeXBJRnpwbU5YU2RuV1FnPT0.png?imageView&thumbnail=1680x0&quality=96&stripmeta=0&type=jpg%7Cwatermark&type=2&text=wqkgWmFjaGFyeSAvIG1hcmNob24ubG9mdGVyLmNvbQ==&font=bXN5aA==&gravity=southwest&dissolve=30&fontsize=340&dx=16&dy=20&stripmeta=0)

![](http://imglf1.nosdn.127.net/img/MGpGUW9CdGlzcDZ3Q2F5L2N4alRKYXh4Znh2YkFrZWhCK1JXS1RseHpEMkVqSU1pc0J1dUV3PT0.png?imageView&thumbnail=1680x0&quality=96&stripmeta=0&type=jpg%7Cwatermark&type=2&text=wqkgWmFjaGFyeSAvIG1hcmNob24ubG9mdGVyLmNvbQ==&font=bXN5aA==&gravity=southwest&dissolve=30&fontsize=340&dx=16&dy=20&stripmeta=0)
